# Code Citations

## License: unknown
https://github.com/FreeWisdom/blog/tree/dc3ffd87c4b897fd51cd00fed7ed4e8af41ac56c/node.js/note/09-%E9%A1%B9%E7%9B%AE%E8%AE%B0%E5%BD%95.md

```
{
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;
```


## License: unknown
https://github.com/Qu1lby/BigBen/tree/60e71089a033b52c367444e1a4d20923f5ba1d56/node_modules/htmlspecialchars/index.js

```
str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot
```


## License: unknown
https://github.com/YASHajjubhai/Monkey-Game/tree/c28641ca97b4269031cbd65bdb8859739cf05e3a/p5.js

```
.replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;'
```


## License: unknown
https://github.com/tomasroaldsnes/fraidetilmvp/tree/723dc9a364847b953ebeee4f756f7378587313d5/node_modules/netlify-cms-core/src/actions/entries.ts

```
g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };
  const
```

